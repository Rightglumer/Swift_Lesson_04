import Cocoa

enum EngineState {
    case Started, Stopped
}

enum WindowState {
    case Open, Close
}

enum TransmissionState {
    case Sport, Comfort, Eco
}

class Car {
    let model : String
    let year : Int
    var windowState : WindowState
    var engineState : EngineState
    
    init(model : String, year : Int){
        self.model = model
        self.year = year
        self.windowState = .Close
        self.engineState = .Stopped
    }
    
    func openWindow() {
        windowState = .Open
    }
    
    func closeWindow() {
        windowState = .Close
    }
    
    func startEngine() {
        engineState = .Started
    }
    
    func stopEngine() {
        engineState = .Stopped
    }
    
    func setDrive() {
        startEngine()
    }
    
    func printInfo() {
        print("model is \(model), year is \(year)")
    }
    
    func printState() {
        print("The windows are \(windowState)")
        print("The engine is \(engineState)")
    }
    
}

class SportCar : Car {
    var transmissionState : TransmissionState
    let maxSpeed : Int
    
    init (model : String, year : Int, maxSpeed : Int) {
        self.transmissionState = .Comfort
        self.maxSpeed = maxSpeed
        super.init(model: model, year: year)
    }
    
    func goDragRacing() {
        transmissionState = .Sport
    }
    
    func goCivilianRacing() {
        transmissionState = .Comfort
    }
    
    override func setDrive() {
        super.setDrive()
        if (transmissionState == .Sport) {
            print("Wrooom-wroom starting")
        } else {
            print("Slow starting ")
        }
    }
    
    override func printInfo() {
        print("The fastest sport car. Max speed is \(maxSpeed)")
        super.printInfo()
    }
    
    override func printState() {
        super.printState()
        print("Transmission state is \(transmissionState)")
    }
}

class TruckCar : Car {
    let maxCargo : Double
    var curCargo : Double
    
    init (model : String, year : Int, maxCargo : Double) {
        self.maxCargo = maxCargo
        curCargo = 0
        super.init(model: model, year: year)
    }
    
    func fillCargo(cargo : Double) {
        if (curCargo + cargo > maxCargo) {
            print("Truck is full")
        } else {
            curCargo += cargo
        }
    }
    
    func emptyCargo() {
        curCargo = 0
    }
    
    override func setDrive() {
        super.setDrive()
        if (curCargo == 0) {
            print("Fast starting")
        } else {
            print("Very carefully starting")
        }
    }
    
    override func printInfo() {
        print("Very good truck. Max capacity is \(maxCargo)")
        super.printInfo()
    }
    
    override func printState() {
        super.printState()
        print("Current cargo is \(curCargo)")
    }
}

var honda = SportCar(model: "Civic", year: 2019, maxSpeed: 220)
var gazelle = TruckCar(model: "2752", year: 1998, maxCargo: 15.0)
var ferrari = SportCar(model: "F450", year: 2010, maxSpeed: 450)

honda.printInfo()
honda.printState()
honda.goDragRacing()
honda.printState()
honda.setDrive()
print("")
gazelle.printInfo()
gazelle.fillCargo(cargo: 12.0)
gazelle.printState()
gazelle.setDrive()
print("")
ferrari.printInfo()
ferrari.setDrive()
ferrari.printState()
